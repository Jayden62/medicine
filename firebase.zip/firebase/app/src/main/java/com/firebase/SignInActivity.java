package com.firebase;

import android.app.AlertDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class SignInActivity extends AppCompatActivity implements View.OnClickListener, TextWatcher {

    private Button mButtonSignIn;
    private TextView mTextViewForgetPws;
    private TextView mTextViewRegister;
    private EditText mEditTextPhone;
    private EditText mEditTextPassword;

    private String TAG = "SignInActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        findViewById();
        captureOnClick();
    }

    private void captureOnClick() {
        mButtonSignIn.setOnClickListener(this);
        mTextViewForgetPws.setOnClickListener(this);
        mTextViewRegister.setOnClickListener(this);
        mEditTextPhone.addTextChangedListener(this);
    }

    private void findViewById() {
        mButtonSignIn = findViewById(R.id.mButtonSignIn);
        mTextViewForgetPws = findViewById(R.id.mTextViewForgetPwd);
        mTextViewRegister = findViewById(R.id.mTextViewRegister);
        mEditTextPhone = findViewById(R.id.mEditTextPhone);
        mEditTextPassword = findViewById(R.id.mEditTextPassword);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.mButtonSignIn:
                /**
                 * Check user login
                 */
                break;
            case R.id.mTextViewForgetPwd:
                /**
                 * Open dialog
                 */
                createDialog();
                break;
            case R.id.mTextViewRegister:
                /**
                 * Move to SignUp screen
                 */
                Intent intent = new Intent(this, SignUpActivity.class);
                startActivity(intent);
                break;
        }
    }

    private void createDialog() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View view = inflater.inflate(R.layout.forgot_password_dialog, null);
        dialog.setView(view);
        final ImageView mImageViewClose = view.findViewById(R.id.mImageViewClose);
        final Button mButtonSend = view.findViewById(R.id.mButtonSend);
        final EditText mEditTextPhone = view.findViewById(R.id.mEditTextPhone);
        final AlertDialog alertDialog = dialog.create();
        mButtonSend.setEnabled(false);

        mImageViewClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
        mButtonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "send.");
            }
        });

        mEditTextPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().equals("") || !s.toString().isEmpty()) {
                    mButtonSend.setEnabled(true);
                } else {
                    mButtonSend.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        dialog.setCancelable(true);
        alertDialog.show();
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (!s.toString().equals("") || !s.toString().isEmpty()) {
            mButtonSignIn.setEnabled(true);
        } else {
            mButtonSignIn.setEnabled(false);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}
